int some_helper() {
  return 1;
}
